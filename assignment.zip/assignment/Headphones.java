package org.assignment;

public class Headphones extends Product {
    public Headphones(String name, double price, boolean available) {
        super(name, price, available);
    }
}
