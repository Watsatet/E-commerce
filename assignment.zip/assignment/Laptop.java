package org.assignment;

public class Laptop extends Product {
    public Laptop(String name, double price, boolean available) {
        super(name, price, available);
    }
}
